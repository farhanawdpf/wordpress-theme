
  <!-- FOOTER -->
  <footer class="container">
  <img src="<?php echo esc_url( get_theme_mod( 'logo' ) ); ?>" alt="Product 1" width="100" height="100">
    <p class="float-end"><a href="#">Back to top</a></p>
    <p><?php 
            echo get_theme_mod('my_copyright_text', __( 'All Rights Reserved', 'my_theme' ) 
        ); 
        ?> <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
  </footer>
</main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>
