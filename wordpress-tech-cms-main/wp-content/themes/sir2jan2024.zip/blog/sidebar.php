<h1>this is sidebar</h1>

<?php
dynamic_sidebar('sidebar-1')
?>